pyinstaller.exe  ShiftGrid.spec
