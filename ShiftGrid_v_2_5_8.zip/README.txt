<ShiftGrid release version 2.5.8>

The ShiftGrid automatic trading system welcomes you!

ShiftGrid release version 2.5.8: This revision includes significant updates that make the program more stable and easier to interact with. 

The main differences from the previous version:

1. The function of selling the entire asset has been removed. The practice of using a robot has shown that replacing a tradable asset 
is a fairly serious investment decision, requires a balanced approach and comprehensive analysis, therefore it should not be carried 
out "in field conditions".  

2. Long-term operation of the robot revealed that there was no need to use an external watchdog. Therefore, the built-in external 
watchdog server has been removed, and the port setting for interacting with the external watchdog has been abolished. The built-in 
watchdog can still be disabled (this is necessary if the robot is running, for example, on a corporate computer or server, restarting 
which is undesirable or prohibited).

3. In order to ensure as stable a connection to the network as possible, especially with a significant number of instances of the robot 
running simultaneously on the computer, the frequency of sending requests to the exchange server (ping) in this version varies 
randomly. For example, if the ping time is set to 30 seconds in the settings, the actual query time will vary randomly from 24 to 36 
seconds. This significantly reduces the likelihood of two or more robot instances sending requests at the same time.

4. Additionally, a certain rearrangement of the sequence of configurable parameters has been performed in the configuration file 
"settings.cfg". Now the parameters are arranged more logically and intuitively.  In particular, the DELTA parameter has now been 
replaced by the more understandable WITHDRAW_PRC parameter (how much interest to withdraw to the wallet) and is located after 
the WITHDRAW parameter (conditions for allowing withdrawal of profits from the transaction). 

5. For ease of viewing, the event log file "log.txt" is now created in the main application folder.

ATTENTION! The above differences lead to the need to make appropriate changes to the "settings.cfg" configuration file. The easiest 
way would be to use the file provided in the distribution configurations where you will need to insert your settings (exchange, API keys, 
tradable asset, grid settings, profit withdrawal conditions). 

May the Force be with you!




Автоматическая торговая система ShiftGrid приветствует Вас!

ShiftGrid release version 2.5.8: Данная весия включает существенные обновления, делающие работу программы 
более стабильной,  а взаимодействие с ней - более простым. 

Основные отличия от предыдущей версии:

1.  Удалена функция продажи всего актива. Практика использования робота показала, что замена торгуемого
актива является достаточно серьезным инвестиционным решением, требует взвешенного подхода и комплексного 
анализа,  поэтому не должна производиться "в походных условиях".  

2.  Длительная эксплуатация робота выявила отсутствие необходимости в использовании внешнего ватчдога.
Поэтому встроенный сервер внешнего ватчдога удален, настройка порта для взаимодействия с внешним ватчдогом
упразднена. Встроенный ватчдог по-прежнему можно отключить (это необходимо, если робот запускается, например,
на корпоративном компьютере или сервере, перезагрузка которого нежелательна или запрещена).

3.  В целях обеспечения как можно более устойчивого соединения с сетью, особенно при значительном количестве
одновременно запущенных на компьютере экземпляров робота, периодичность отправки запросов на сервер
биржи (пинг) в данной версии изменяется по случайному закону. Например, если в настройках установлено время 
пинга 30 секунд, то фактическое время следования запросов будет изменяться случайным образом в пределах
от 24 до 36 секунд. Таким образом, существенно уменьшается вероятность одновременной отправки запросов двумя
и более экземплярами робота.

 4.  Дополнительно произведена определенная перегруппировка последовательности настраиваемых параметров
в файле конфигурации settings.cfg. Теперь параметры расположены более логично и интуитивно понятно.  В частности,
параметр DELTA теперь заменен более понятным параметром WITHDRAW_PRC (сколько процентов выводить в кошелек)
и располагается после параметра WITHDRAW (условия разрешения вывода прибыли от сделки). 

5. Для удобства просмотра файл  лога событий log.txt теперь создается в главной папке приложения.

ВНИМАНИЕ! Вышеперечисленные отличия приводят к необходимости внесения соответствующих изменений в файл
конфигурации settings.cfg. Самым простым способом будет использовать поставляемый в дистрибутиве файл
конфигурации, куда нужно будет вставить Ваши настройки (биржу, API-ключи, торгуемый актив, настройки сетки, условия
вывода прибыли). 

Да пребудет с Вами Сила!



***
©2025 ShiftGrid



